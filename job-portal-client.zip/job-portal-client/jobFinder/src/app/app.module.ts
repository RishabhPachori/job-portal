import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {ReactiveFormsModule, FormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import {HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './Auth/home/home.component';
import { LoginComponent } from './Auth/login/login.component';
import { RegisterComponent } from './Auth/register/register.component';
import { UserregisterComponent } from './Auth/register/userregister/userregister.component';
import { RecruiterregisterComponent } from './Auth/register/recruiterregister/recruiterregister.component';
import { UserloginComponent } from './Auth/login/userlogin/userlogin.component';
import { RecruiterloginComponent } from './Auth/login/recruiterlogin/recruiterlogin.component';
import { PostjobComponent } from './recruiter/postjob/postjob.component';
import { RecruiterdashboardComponent } from './recruiter/recruiterdashboard/recruiterdashboard.component';
import { AppliedUsersComponent } from './recruiter/recruiterdashboard/applied-users/applied-users.component';
import { PostedjobsComponent } from './recruiter/recruiterdashboard/postedjobs/postedjobs.component';
import { RecruiterprofileComponent } from './recruiter/recruiterprofile/recruiterprofile.component';
import { DashboardComponent } from './User/dashboard/dashboard.component';
import { UserprofileComponent } from './User/userprofile/userprofile.component';
import { JobsComponent } from './User/dashboard/jobs/jobs.component';
import { AppliedjobsComponent } from './User/dashboard/appliedjobs/appliedjobs.component';
import { ForuserService } from './shared/foruser.service';
import { ForrecruiterService } from './shared/forrecruiter.service';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent,
    LoginComponent,
    RegisterComponent,
    UserregisterComponent,
    RecruiterregisterComponent,
    UserloginComponent,
    RecruiterloginComponent,
    PostjobComponent,
    RecruiterdashboardComponent,
    AppliedUsersComponent,
    PostedjobsComponent,
    RecruiterprofileComponent,
    DashboardComponent,
    UserprofileComponent,
    JobsComponent,
    AppliedjobsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [ForuserService,ForrecruiterService],
  bootstrap: [AppComponent]
})
export class AppModule { }
