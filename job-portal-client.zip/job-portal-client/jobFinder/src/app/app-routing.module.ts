import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {HomeComponent} from './Auth/home/home.component';
import {LoginComponent} from './Auth/login/login.component';
import { UserloginComponent } from './Auth/login/userlogin/userlogin.component';
import { RecruiterloginComponent } from './Auth/login/recruiterlogin/recruiterlogin.component';
import { RegisterComponent } from './Auth/register/register.component';
import { UserregisterComponent } from './Auth/register/userregister/userregister.component';
import { RecruiterregisterComponent } from './Auth/register/recruiterregister/recruiterregister.component';
import { RecruiterdashboardComponent } from './recruiter/recruiterdashboard/recruiterdashboard.component';
import { AppliedUsersComponent } from './recruiter/recruiterdashboard/applied-users/applied-users.component';
import { PostedjobsComponent } from './recruiter/recruiterdashboard/postedjobs/postedjobs.component';
import { PostjobComponent } from './recruiter/postjob/postjob.component';
import { RecruiterprofileComponent } from './recruiter/recruiterprofile/recruiterprofile.component';
import { DashboardComponent } from './User/dashboard/dashboard.component';
import { JobsComponent } from './User/dashboard/jobs/jobs.component';
import { AppliedjobsComponent } from './User/dashboard/appliedjobs/appliedjobs.component';
import { UserprofileComponent } from './User/userprofile/userprofile.component';



const routes: Routes = [
  {path: '', redirectTo: 'home', pathMatch: 'full'},
  {path: 'home', component: HomeComponent},
  {path: 'login', component: LoginComponent, children: [
    {path: 'user-login', component: UserloginComponent},
    {path: 'recruiter-login', component: RecruiterloginComponent}
  ]},
  {path: 'register', component: RegisterComponent, children: [
    {path: 'user-register', component: UserregisterComponent},
    {path: 'recruiter-register', component: RecruiterregisterComponent}
  ]},
  {path: 'recruiter-dashboard', component: RecruiterdashboardComponent, children: [
    {path: 'posted-jobs', component: PostedjobsComponent},
    {path: 'applied-users', component: AppliedUsersComponent}
  ]},
  {path: 'recruiter/recruiter-profile', component: RecruiterprofileComponent},
  {path: 'recruiter/post-job', component: PostjobComponent},
  {path: 'dashboard', component: DashboardComponent, children: [
    {path: 'jobs', component: JobsComponent},
    {path: 'applied-jobs', component: AppliedjobsComponent}
  ]},
  {path: 'User/user-profile', component: UserprofileComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
