import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';
import { ForuserService } from '../../shared/foruser.service';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  providers: [ForuserService]
})
export class DashboardComponent implements OnInit {

  constructor(private router: Router, private activeroute: ActivatedRoute,private userService: ForuserService) { }
  username : any;

  ngOnInit(): void {
    this.username = this.userService.getpayload().username;
  }

  gotoProfilePage(){
    this.router.navigate(['User/user-profile']);
  }

  logoutUser(){
    this.userService.logout();
    this.router.navigate(['login/user-login']);
  }

  jobs(){
    this.router.navigate(['jobs'],{relativeTo:this.activeroute});
  }

  applied_jobs(){
    this.router.navigate(['applied-jobs'],{relativeTo:this.activeroute});

  }
}
