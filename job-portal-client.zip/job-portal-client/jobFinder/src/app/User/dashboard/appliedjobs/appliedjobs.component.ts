import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appliedjobs',
  templateUrl: './appliedjobs.component.html',
  styleUrls: ['./appliedjobs.component.css']
})
export class AppliedjobsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
