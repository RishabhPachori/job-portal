import { Component, OnInit } from '@angular/core';
import { ForuserService } from '../../../shared/foruser.service';

@Component({
  selector: 'app-jobs',
  templateUrl: './jobs.component.html',
  styleUrls: ['./jobs.component.css'],
  providers: [ForuserService]
})
export class JobsComponent implements OnInit {

jobs:any=[];
successmessage : boolean = false;
totaljobs:any;
headers=['Company Name','Job Role','Skills','Experience','Qualifications','Job Type','Job Description',''];

  constructor(private userService: ForuserService) { }

  ngOnInit(): void {
    this.getJobs();
  }
  getJobs(){
    this.userService.getJobs().subscribe(
      (response:any)=>
    {
      if(response !==0)
      {
        this.successmessage = true;
        this.jobs=response.data;
        this.totaljobs=response.data.length;
      } 
    },
    (error)=>{
      console.log(error.msg);
    }
    );
  }
  apply(job:any){
    console.log(job);
    this.userService.applyjob(job).subscribe(
      (response: any)=>{
        console.log(response.message);
      }
    );
  }
}
