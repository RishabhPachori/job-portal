import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';

import { ForuserService } from '../../shared/foruser.service';


@Component({
  selector: 'app-userprofile',
  templateUrl: './userprofile.component.html',
  styleUrls: ['./userprofile.component.css'],
  providers: [ForuserService]
})
export class UserprofileComponent implements OnInit {

  constructor(private router: Router,private userService: ForuserService) { }
  userProfileForm : FormGroup;
  successmessage : any;
  profileInfo : any=[];
  username : any;
  userData : any={};

  ngOnInit(): void {
    this.getProfile();
    this.username =localStorage.getItem("currentemployee");
    this.userProfileForm = new FormGroup({
      'username' : new FormControl('', Validators.required),
      'password' : new FormControl('',[Validators.required, Validators.minLength(8)]),
      'email' : new FormControl('',[Validators.required, Validators.email]),
      'gender' : new FormControl('', Validators.required),
      'phonenumber' : new FormControl('', Validators.required),
      'hometown': new FormControl(''),
      'interests' : new FormControl(''),
      'experience' : new FormControl(''),
      'maritalStatus' : new FormControl('', Validators.required),
      'nationality' : new FormControl(''),
      'languages' : new FormControl(''),
      'currentLocation' : new FormControl(''),
      'lastJobExperience' : new FormControl('', Validators.required),
      'lastDesignation' : new FormControl('', Validators.required),
      'department' : new FormControl(''),
      'reason' : new FormControl('')
    });
  }
  getProfile(){
    this.userService.getUserProfile().subscribe(
      (response: any)=>{
        this.profileInfo = response;
        this.userData = response;
        this.userProfileForm.patchValue({
          _id: this.userService.getpayload()._id,
          username: this.userData.username,
          email: this.userData.email,
          gender: this.userData.gender,
          phonenumber: this.userData.phonenumber,
          hometown: this.userData.hometown,
          interests: this.userData.interests,
          experience: this.userData.experience,
          maritalStatus: this.userData.maritalStatus,
          nationality: this.userData.nationality,
          languages: this.userData.languages,
          currentLocation: this.userData.currentLocation,
          lastJobExperience: this.userData.lastJobExperience,
          lastDesignation: this.userData.lastDesignation,
          department: this.userData.department,
          reason: this.userData.reason
        });
        this.userProfileForm.setValue({
          password: this.userData.password
        });
      }
    );
  }
  
  onSubmit(){
    //console.log(this.userProfileForm.value);
    this.userService.updateUserProfile(this.userProfileForm.value).subscribe(
      (response:any)=>{
        if(response !==0){
          this.successmessage = "profile successfully updated";
          setTimeout(() => {
            this.router.navigate(['/login/user-login']);
          }, 3000);
        }
      },
      (error)=> { console.log(error); }
    );
  }

  // convenience getter for easy access to form fields
  get f() { return this.userProfileForm.controls; }

  logoutuser(){
    this.userService.logout();
    this.router.navigate(['login/user-login']);

  }

}
