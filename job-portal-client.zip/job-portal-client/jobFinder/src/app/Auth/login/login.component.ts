import { Component, OnInit } from '@angular/core';
import {Router, ActivatedRoute} from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router: Router , private activatedroute: ActivatedRoute) { }
  tabset: boolean = false;
  ngOnInit(): void {
  }
  userLoginForm()  {
    this.router.navigate(['user-login'], {relativeTo: this.activatedroute});
    this.tabset = true;
  }

  recruiterLoginForm()  {
    this.router.navigate(['recruiter-login'], {relativeTo: this.activatedroute});
    this.tabset = true;
  }
}
