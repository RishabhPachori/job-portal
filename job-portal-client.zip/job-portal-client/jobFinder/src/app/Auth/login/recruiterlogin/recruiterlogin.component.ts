import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';

import { ForrecruiterService } from '../../../shared/forrecruiter.service';

@Component({
  selector: 'app-recruiterlogin',
  templateUrl: './recruiterlogin.component.html',
  styleUrls: ['./recruiterlogin.component.css'],
  providers: [ForrecruiterService]
})
export class RecruiterloginComponent implements OnInit {

  constructor(private router: Router, private recruiterService: ForrecruiterService) { }
  loginsuccess: any;
  loginfailed: any;
  recruiterLoginForm: FormGroup;
  ngOnInit(): void {
    this.recruiterLoginForm = new FormGroup({
      "companyEmail" : new FormControl('',[Validators.required,Validators.email]),
      "password" : new FormControl('',[Validators.required,Validators.minLength(8)])
    });
  }

  recruiterLogin(){
    //console.log(this.recruiterLoginForm.value);
    this.recruiterService.recruiter_login(this.recruiterLoginForm.value).subscribe(
      (response:any)=>{
        if(response.status !== 0){
          this.loginsuccess = response.message;
          localStorage.setItem('token',response.token);
          let payload = this.recruiterService.getpayload();
          localStorage.setItem("currentcompany",payload.companyName);
          this.recruiterLoginForm.reset();
          setTimeout(() => {
            this.router.navigate(['recruiter-dashboard/posted-jobs']);
          }, 3000);
        }
      },
      (error)=>{ this.loginfailed = "Invalid Username/Password";}
    );
  }

  recruiterRegister(){
    this.router.navigate(['register/recruiter-register']);
  }
}
