import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';

import { ForuserService } from '../../../shared/foruser.service';

@Component({
  selector: 'app-userlogin',
  templateUrl: './userlogin.component.html',
  styleUrls: ['./userlogin.component.css'],
  providers :[ForuserService]
})
export class UserloginComponent implements OnInit {

  constructor(private router: Router, private userService: ForuserService) { }
  loginsuccess: any;
  loginfailed: any;
  userLoginForm: FormGroup;
  
  ngOnInit(): void {
    this.userLoginForm = new FormGroup({
      "email" : new FormControl('',[Validators.required,Validators.email]),
      "password" : new FormControl('',[Validators.required,Validators.minLength(8)])
    });

  }

  userLogin(){
    //console.log(this.userLoginForm.value);
    this.userService.user_login(this.userLoginForm.value).subscribe(
      (response:any)=>{
        if(response.status !== 0){
          this.loginsuccess = response.message;
          localStorage.setItem('token',response.token);
          let payload = this.userService.getpayload();
          localStorage.setItem("currentemployee",payload.username);
          this.userLoginForm.reset();
          setTimeout(() => {
            this.router.navigate(['dashboard/jobs']);
          }, 3000);
        }
      },
      (error)=>{ this.loginfailed = "Invalid Email or Password";}
    );
  }

  userRegister(){
    this.router.navigate(['register/user-register']);
  }

}
