import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ForuserService } from '../../../shared/foruser.service';
//import { User } from '../../../shared/user.model';

@Component({
  selector: 'app-userregister',
  templateUrl: './userregister.component.html',
  styleUrls: ['./userregister.component.css'],
  providers :[ForuserService]
})
export class UserregisterComponent implements OnInit {

  constructor(private router: Router, private userService: ForuserService) { }
  UserRegisterForm: FormGroup;
  registrationsuccess: any;
  registrationfailed: any;
  ngOnInit(): void {
    this.UserRegisterForm = new FormGroup({
      'username' : new FormControl('', Validators.required),
      'password' : new FormControl('',[Validators.required, Validators.minLength(8)]),
      'email' : new FormControl('',[Validators.required, Validators.email]),
      'gender' : new FormControl('', Validators.required),
      'phonenumber' : new FormControl('', Validators.required),
      'hometown': new FormControl(''),
      'interests' : new FormControl(''),
      'experience' : new FormControl(''),
      'maritalStatus' : new FormControl('', Validators.required),
      'nationality' : new FormControl(''),
      'languages' : new FormControl(''),
      'currentLocation' : new FormControl(''),
      'lastJobExperience' : new FormControl('', Validators.required),
      'lastDesignation' : new FormControl('', Validators.required),
      'department' : new FormControl(''),
      'reason' : new FormControl('')
    });
  }
  registeruser() {
    //console.log(this.UserRegisterForm.value);
    this.userService.user_register(this.UserRegisterForm.value).subscribe(
      (response:any)=>{
        if(response.status !== 0){
          this.registrationsuccess="Congratulations..!! You are registered successfully";
          this.UserRegisterForm.reset();
          setTimeout(() => {
            this.router.navigate(['/login/user-login']);
          }, 3000);
        }
      },
      (error)=>{
        this.registrationfailed = "You are already registered";
      }
    );
  }
}
