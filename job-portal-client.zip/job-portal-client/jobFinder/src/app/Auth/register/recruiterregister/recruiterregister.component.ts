import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ForrecruiterService } from '../../../shared/forrecruiter.service';

@Component({
  selector: 'app-recruiterregister',
  templateUrl: './recruiterregister.component.html',
  styleUrls: ['./recruiterregister.component.css'],
  providers :[ForrecruiterService]
})
export class RecruiterregisterComponent implements OnInit {

  constructor(private router: Router,private recruiterService: ForrecruiterService) { }
  RecruiterRegisterForm: FormGroup;
  registrationsuccess: any;
  registrationfailed: any;
  ngOnInit(): void {
    this.RecruiterRegisterForm = new FormGroup({
      'companyName' : new FormControl('', Validators.required),
      'password' : new FormControl('',[Validators.required, Validators.minLength(8)]),
      'companyEmail' : new FormControl('',[Validators.required, Validators.email]),
      'industryType' : new FormControl('', Validators.required),
      'experience' : new FormControl('', Validators.required),
      'about' : new FormControl('', Validators.required)
    });
  }
  registerrecruiter() {
    //console.log(this.RecruiterRegisterForm.value);
    this.recruiterService.recruiter_register(this.RecruiterRegisterForm.value).subscribe(
      (response:any)=>{
        if(response.status !== 0){
          this.registrationsuccess="Congratulations..!! You are registered successfully";
          this.RecruiterRegisterForm.reset();
          setTimeout(() => {
            this.router.navigate(['/login/recruiter-login']);
          }, 3000);
        }
      },
      (error)=>{
        this.registrationfailed = "You are already registered";
      }
    );
  }
}
