import { TestBed } from '@angular/core/testing';

import { ForrecruiterService } from './forrecruiter.service';

describe('ForrecruiterService', () => {
  let service: ForrecruiterService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ForrecruiterService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
