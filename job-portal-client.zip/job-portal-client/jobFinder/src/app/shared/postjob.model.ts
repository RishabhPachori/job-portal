export class Postjob {
    _id: string;
    jobRole: string;
    experience: number;
    skills: string;
    qualifications: string;
    jobDescription: string;
    jobType: string;
}
