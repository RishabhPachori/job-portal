import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';

import { User } from './user.model';
import { Appliedpostjob } from './appliedpostjob.model';

@Injectable({
  providedIn: 'root'
})
export class ForuserService {
  users: User[];
  appliedJobPosts: Appliedpostjob[];
  readonly baseURL = 'http://localhost:8080/';

  constructor(private http:HttpClient) { }
  user_register(user : User){
    return this.http.post(`${this.baseURL}register-user`,user,{
      headers: new HttpHeaders().append("Content-Type","application/json")
      });
  }

  user_login(user : User){
    return this.http.post(`${this.baseURL}login-user`,user,{
      withCredentials: true,
      headers: new HttpHeaders().append("Content-Type","application/json")
      });
  }

  gettoken()
  {
    return localStorage.getItem('token');
  }
  
  getpayload()
  {
    let token = this.gettoken();
    return JSON.parse(window.atob(token.split('.')[1]));
  }

  getJobs(){
    const httpOptions = {
      headers : new HttpHeaders({
        "Content-Type":"application/json",
        "Authorization" : "Bearer"+ " " +this.gettoken()
      })
    }
    return this.http.get(`${this.baseURL}user/posts`,httpOptions);
  }

  applyjob(appliedJobPosts: Appliedpostjob)
  {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type":"application/json",
        "Authorization" : "Bearer"+ " " +this.gettoken()
      })
    };
    return this.http.post(`${this.baseURL}user/applied-jobs`,appliedJobPosts,httpOptions);
  }

  updateUserProfile(user : User){
    const httpOptions = {
      headers : new HttpHeaders({
        "Content-Type":"application/json",
        "Authorization": "Bearer" + " " + this.gettoken()
      })
    }
    return this.http.put(`${this.baseURL}user/${this.getpayload()._id}`,user,httpOptions);
  }
  
  getUserProfile(){
    const httpOptions = {
      headers : new HttpHeaders({
        "Content-Type":"application/json",
        "Authorization": "Bearer" + " " +this.gettoken()
      })
    }
    return this.http.get(`${this.baseURL}user/${this.getpayload()._id}`,httpOptions);
  }

  logout(){
    localStorage.removeItem("token");
    localStorage.removeItem("currentemployee");
  }
}
