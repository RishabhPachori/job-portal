export class Appliedpostjob {
    _id: string;
    recruiter:string;
    recruiter_name:string;
    jobRole: string;
    experience: number;
    skills: string;
    qualifications: string;
    jobDescription: string;
    jobType: string;
    postedDate: string;
}
