import { Appliedpostjob } from './appliedpostjob.model';

describe('Appliedpostjob', () => {
  it('should create an instance', () => {
    expect(new Appliedpostjob()).toBeTruthy();
  });
});
