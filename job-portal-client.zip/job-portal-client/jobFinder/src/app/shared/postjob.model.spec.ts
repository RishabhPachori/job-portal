import { Postjob } from './postjob.model';

describe('Postjob', () => {
  it('should create an instance', () => {
    expect(new Postjob()).toBeTruthy();
  });
});
