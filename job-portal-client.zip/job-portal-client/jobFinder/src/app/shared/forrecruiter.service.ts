import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';

import { map } from 'rxjs/operators';

import { Recruiter } from './recruiter.model';
import { Postjob } from './postjob.model';

@Injectable({
  providedIn: 'root'
})
export class ForrecruiterService {
  recruiters: Recruiter[];
  postjob: Postjob[];
  readonly baseURL = 'http://localhost:8080/';


  constructor(private http:HttpClient) { }
  
  recruiter_register(recruiter : Recruiter){
    return this.http.post(`${this.baseURL}register-recruiter`,recruiter,{
      headers: new HttpHeaders().append("Content-Type","application/json")
      });
  }

  recruiter_login(recruiter : Recruiter){
    return this.http.post(`${this.baseURL}login-recruiter`,recruiter,{
      withCredentials: true,
      headers: new HttpHeaders().append("Content-Type","application/json")
      });
  }
  
  gettoken()
  {
    return localStorage.getItem('token');
  }

  getpayload()
  {
    let token = this.gettoken();
    return JSON.parse(window.atob(token.split('.')[1]));
  }

  post_job(postjob: Postjob){
    const httpOptions = {
      headers : new HttpHeaders({
        "Content-Type":"application/json",
        "Authorization" : "Bearer"+ " " +this.gettoken()
      })
    }
    return this.http.post(`${this.baseURL}post-job`,postjob,httpOptions);
  }

  getPostedJobs(){
    const httpOptions = {
      headers : new HttpHeaders({
        "Content-Type":"application/json",
        "Authorization" : "Bearer"+ " " +this.gettoken()
      })
    }
    return this.http.get(`${this.baseURL}recruiter/posts`,httpOptions);
  }
  

  updateRecruiterProfile(recruiter : Recruiter){
    const httpOptions = {
      headers : new HttpHeaders({
        "Content-Type":"application/json",
        "Authorization": "Bearer" + " " + this.gettoken()
      })
    }
    return this.http.put(`${this.baseURL}recruiter/${this.getpayload()._id}`,recruiter,httpOptions);
  }
  
  getRecruiterProfile(){
    const httpOptions = {
      headers : new HttpHeaders({
        "Content-Type":"application/json",
        "Authorization": "Bearer" + " " +this.gettoken()
      })
    }
    return this.http.get(`${this.baseURL}recruiter/${this.getpayload()._id}`,httpOptions);
  }


  logout(){
    localStorage.removeItem("token");
    localStorage.removeItem("currentcompany");
  }
}
