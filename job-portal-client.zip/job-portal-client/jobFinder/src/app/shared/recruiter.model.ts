export class Recruiter {
    _id: string;
    companyName: string;
    password: string;
    companyEmail: string;
    industryType: string;
    experience: number;
    about: string;
}
