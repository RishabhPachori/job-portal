export class User {
    _id: string;
    username: string;
    password: string;
    email: string;
    gender: string;
    phonenumber: number;
    hometown: string;
    interests: Array<String>;
    experience: number;
    maritalStatus: string;
    nationality: string;
    languages: string;
    currentLocation: string;
    lastJobExperience: number;
    lastDesignation: string;
    department: Array<String>;
    reason: string;
}
