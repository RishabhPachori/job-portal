import { TestBed } from '@angular/core/testing';

import { ForuserService } from './foruser.service';

describe('ForuserService', () => {
  let service: ForuserService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ForuserService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
