import { Component, OnInit } from '@angular/core';
import { ForrecruiterService } from '../../../shared/forrecruiter.service';

@Component({
  selector: 'app-postedjobs',
  templateUrl: './postedjobs.component.html',
  styleUrls: ['./postedjobs.component.css']
})
export class PostedjobsComponent implements OnInit {
  headers=["Job Role","Experience","Skills","Qualifications","Job Description","Job Type","Posted Date",""];
  posted: any=[];
  successmessage:boolean = false;
  totaljobs: any;
  nojobs: any;

  constructor(private recruiterService : ForrecruiterService) { }

  ngOnInit(): void {
    this.postedJobs();
  }
  postedJobs(){
    this.recruiterService.getPostedJobs().subscribe(
      (response:any)=>{
        if(response !==0){
          this.posted = response.data;
          this.totaljobs = response.data.length;
          this.successmessage = true;
        }
      },
      (error)=>{
        console.log(error);
      }
    );
  }
}
