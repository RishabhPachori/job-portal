import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';

import { ForrecruiterService } from '../../shared/forrecruiter.service';

@Component({
  selector: 'app-recruiterdashboard',
  templateUrl: './recruiterdashboard.component.html',
  styleUrls: ['./recruiterdashboard.component.css'],
  providers: [ForrecruiterService]
})
export class RecruiterdashboardComponent implements OnInit {

  constructor(private router: Router, private activeroute: ActivatedRoute,private recruiterService: ForrecruiterService) { }
  companyName : any;

  ngOnInit(): void {
    this.companyName= this.recruiterService.getpayload().companyName;
  }
  gotoProfilePage(){
    this.router.navigate(['recruiter/recruiter-profile']);
  }
  logoutRecruiter(){
    this.recruiterService.logout();
    this.router.navigate(['login/recruiter-login']);
  }
  applied_users(){
    this.router.navigate(['applied-users'],{relativeTo:this.activeroute});
  }
  posted_jobs(){
    this.router.navigate(['posted-jobs'],{relativeTo:this.activeroute});
  }
}




