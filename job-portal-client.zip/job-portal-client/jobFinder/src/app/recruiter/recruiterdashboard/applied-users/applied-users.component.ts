import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-applied-users',
  templateUrl: './applied-users.component.html',
  styleUrls: ['./applied-users.component.css']
})
export class AppliedUsersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
