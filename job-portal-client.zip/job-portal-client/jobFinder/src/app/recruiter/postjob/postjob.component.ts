import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, FormGroup,Validators } from '@angular/forms';

import { ForrecruiterService } from '../../shared/forrecruiter.service';

@Component({
  selector: 'app-postjob',
  templateUrl: './postjob.component.html',
  styleUrls: ['./postjob.component.css'],
  providers: [ForrecruiterService]
})
export class PostjobComponent implements OnInit {

  constructor(private router: Router,private recruiterService: ForrecruiterService) { }
  postedjob : any;
  postederror : any;
  postJobForm: FormGroup;
  companyName : any;

  ngOnInit(): void {
    this.postJobForm = new FormGroup({
      "jobRole" : new FormControl('',Validators.required),
      "experience" : new FormControl('',Validators.required),
      "skills" : new FormControl('',Validators.required),
      "qualifications" : new FormControl('',Validators.required),
      "jobDescription" : new FormControl('',Validators.required),
      "jobType" : new FormControl('',Validators.required)
    });
    this.companyName=this.recruiterService.getpayload().companyName;
  }
  
  logoutRecruiter(){
    this.recruiterService.logout();
    this.router.navigate(['login/recruiter-login']);
  }

  postjob(){
    //console.log(this.postJobForm.value);
    this.recruiterService.post_job(this.postJobForm.value).subscribe(
      (response:any)=>{
        if(response.status !== 0){
          this.postedjob = response.message;
          this.postJobForm.reset();
          setTimeout(() => {
            this.router.navigate(['recruiter-dashboard/posted-jobs']);
          }, 3000);
        }
      },
      (error)=>{ this.postederror = "job is not posted";}
    );
  }
}
