import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ForrecruiterService } from '../../shared/forrecruiter.service';

@Component({
  selector: 'app-recruiterprofile',
  templateUrl: './recruiterprofile.component.html',
  styleUrls: ['./recruiterprofile.component.css'],
  providers: [ForrecruiterService]
})
export class RecruiterprofileComponent implements OnInit {

  constructor(private router: Router,private recruiterService: ForrecruiterService) { }
  recruiterProfileForm : FormGroup;
  successmessage : any;
  profileInfo : any=[];
  companyName : any;
  recruiterData : any={};
  

  ngOnInit(): void {
    this.getProfile();
    this.companyName =localStorage.getItem("currentcompany");
    this.recruiterProfileForm = new FormGroup({
      'companyName' : new FormControl('', Validators.required),
      'password' : new FormControl('',[Validators.required,Validators.minLength(8)]),
      'companyEmail' : new FormControl('',[Validators.required, Validators.email]),
      'industryType' : new FormControl('', Validators.required),
      'experience' : new FormControl('', Validators.required),
      'about' : new FormControl('', Validators.required)

    });
  }

  getProfile(){
    this.recruiterService.getRecruiterProfile().subscribe(
      (response : any)=>{
        this.profileInfo = response;
        this.recruiterData = response;
        this.recruiterProfileForm.patchValue({
          _id: this.recruiterService.getpayload()._id,
          companyName: this.recruiterData.companyName,
          companyEmail: this.recruiterData.companyEmail,
          industryType: this.recruiterData.industryType,
          experience: this.recruiterData.experience,
          about: this.recruiterData.about
        });
        this.recruiterProfileForm.setValue({
          password: this.recruiterData.password
        });
      }
    );
  }

  onSubmit(){
    this.recruiterService.updateRecruiterProfile(this.recruiterProfileForm.value).subscribe(
      (response:any)=>{
        if(response !==0){
          this.successmessage = "profile successfully updated";
          setTimeout(() => {
            this.router.navigate(['/login/recruiter-login']);
          }, 3000);
        }
      },
      (error)=> { console.log(error); }
    );
  }

   // convenience getter for easy access to form fields
   get f() { return this.recruiterProfileForm.controls; }
  
  logoutrecruiter(){
    this.recruiterService.logout();
    this.router.navigate(['login/recruiter-login']);

  }

}
