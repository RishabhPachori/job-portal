/**
 * @file methods.js
 * @description contains all the methods for throwing errors.
 */
const { AppError } = require("./appError");
const { constants } = require("../config");
const { ERROR , LOG_LEVELS } = constants;

/**
 * Method for throwing Bad Request Error 
 * @param {string} message Error Message
 * @param {boolean} isOerational Determines whether our app throws error intentionally 
 * or its unhandled rejection or uncaught Exception. Default true.
 */
const throwBadRequestError = (message, isOerational = true) => {
    throw new AppError(LOG_LEVELS.ERROR,ERROR.BAD_REQUEST.TYPE,message,ERROR.BAD_REQUEST.CODE,isOerational);
};

/**
 * Method for throwing Not Found Error 
 * @param {string} message Error Message
 * @param {boolean} isOerational Determines whether our app throws error intentionally 
 * or its unhandled rejection or uncaught Exception. Default true.
 */

const throwNotFoundError = (message, isOerational = true) => {
    throw new AppError(LOG_LEVELS.ERROR,ERROR.NOT_FOUND.TYPE,message,ERROR.NOT_FOUND.CODE,isOerational);
};

/**
 * Method for throwing Internal Server Error 
 * @param {string} message Error Message
 * @param {boolean} isOerational Determines whether our app throws error intentionally 
 * or its unhandled rejection or uncaught Exception. Default true.
 */

const throwInternalServerError = (message, isOerational = true) => {
    throw new AppError(LOG_LEVELS.ERROR,ERROR.INTERNAL_SERVER_ERROR.TYPE,message,ERROR.INTERNAL_SERVER_ERROR.CODE,isOerational);
};

/**
 * Method for throwing unAuthorized Error 
 * @param {string} message Error Message
 * @param {boolean} isOerational Determines whether our app throws error intentionally 
 * or its unhandled rejection or uncaught Exception. Default true.
 */
const throwUnAuthorizedError = (message, isOerational = true) => {
    throw new AppError(LOG_LEVELS.ERROR,ERROR.UNAUTHORIZED.TYPE,message,ERROR.UNAUTHORIZED.CODE,isOerational);
};

/**
 * Method for throwing unAuthenticated Error 
 * @param {string} message Error Message
 * @param {boolean} isOerational Determines whether our app throws error intentionally 
 * or its unhandled rejection or uncaught Exception. Default true.
 */

const throwUnAuthenticatedError = (message, isOerational = true) => {
    throw new AppError(LOG_LEVELS.ERROR,ERROR.UNAUTHENTICATED.TYPE,message,ERROR.UNAUTHENTICATED.CODE,isOerational);
};


module.exports = {
    throwBadRequestError,
    throwNotFoundError,
    throwInternalServerError,
    throwUnAuthorizedError,
    throwUnAuthenticatedError
};