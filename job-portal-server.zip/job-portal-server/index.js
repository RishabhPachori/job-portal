/**
 * @file index.js
 * @summary Creates HTTP server
 * @description This file is responsible for creating an HTTP server and adding routes.
 * Server is created by binding express app instance.
 * */

const { createServer } = require("http");
const { app,router } = require("./app");
const { log } = require("./errors");
const initiatesRoutes = require("./modules");
const { connectToMongoDb } = require("./db");
const { constants } = require("./config");
const { PORT,LOG_LEVELS } = constants;

connectToMongoDb();
initiatesRoutes(router);

const server = createServer(app);

process.on("unhandledRejection",error =>{
    log(LOG_LEVELS.ERROR,error.message,{ time: new Date() });
    process.exit(1);
});

process.on("uncaughtException",error =>{
    log(LOG_LEVELS.ERROR,error.message,{ time: new Date() });
    process.exit(1);
});

process.on("exit",code=>{
    console.log(`Exiting with code ${code}`);
});


server.listen(PORT,err=>{
    if(err){
        return console.log(`Port not found ${err}`); 
    }
    console.log(`Server Listening at PORT ${PORT}`);
});