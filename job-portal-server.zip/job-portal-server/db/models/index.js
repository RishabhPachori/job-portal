const { Users } = require("./users");
const { Recruiters } = require("./recruiters");
const { Postjobs } = require("./postjobs");
const { Appliedpostjobs } = require("./appliedPostJobs");

module.exports = {
    Users,
    Recruiters,
    Postjobs,
    Appliedpostjobs
};