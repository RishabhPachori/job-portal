/**
 * @file recruiters.js
 * @summary Define recruiter Schema
 */

const mongoose = require("mongoose");

const recruiterSchema = new mongoose.Schema({
    companyName: {
       type : String,
       required : true
   },
   password: {
       type : String,
       required : true
   },
   companyEmail: {
       type : String,
        required : true,
        unique :true
    },
    industryType: {
        type : String,
        required : true
    },
    experience : {
        type : Number,
        required : true
    },
    about : {
        type : String,
        required : true
    }
});

module.exports = {
   Recruiters : mongoose.model("Recruiters",recruiterSchema)
};
