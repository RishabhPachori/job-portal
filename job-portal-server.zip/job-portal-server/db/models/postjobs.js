/**
 * @file postjobs.js
 * @summary Define postJob Schema
 */

const mongoose = require("mongoose");

const postJobSchema = new mongoose.Schema({
    recruiter: {
        type: mongoose.Schema.Types.ObjectId, 
        ref: "Recruiters",
        required : true
    },
    recruiter_name: {
        type : String,
        ref : "Recruiters",
        required : true
    },
    jobRole: {
       type : String,
       required : true
   },
   experience: {
       type : Number,
       required : true
   },
   skills: {
    type : String,
    required : true
    },
    qualifications: {
        type : String,
        required : true
    },
    jobDescription: {
        type : String,
        required : true
    },
    jobType: {
        type : String,
        required : true
    },
    postedDate: {type: Date, default: Date.now}

});

module.exports = {
   Postjobs : mongoose.model("Postjobs",postJobSchema)
};
