/**
 * @file appliedPostJobs.js
 * @summary Define appliedPostjob Schema
 */

const mongoose = require("mongoose");

const appliedPostJobSchema = new mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Users",
        required : true
    },
    post_job: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Postjobs",
        required : true
    },
    recruiter: {
        type: mongoose.Schema.Types.ObjectId, 
        ref: "Recruiters",
        required : true
    },
    recruiter_name: {
        type : String,
        ref : "Recruiters",
        required : true
    },
    jobRole: {
       type : String,
       required : true
   },
   experience: {
       type : Number,
       required : true
   },
   skills: {
    type : String,
    required : true
    },
    qualifications: {
        type : String,
        required : true
    },
    jobDescription: {
        type : String,
        required : true
    },
    jobType: {
        type : String,
        required : true
    },
    postedDate: {type: String,
    required: true
}

});

module.exports = {
    Appliedpostjobs : mongoose.model("Appliedpostjobs",appliedPostJobSchema)
};
