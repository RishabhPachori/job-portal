/**
 * @file users.js
 * @summary Define user Schema
 */

 const mongoose = require("mongoose");

 const userSchema = new mongoose.Schema({
    username: {
        type : String,
        required : true
    },
    password: {
        type : String,
        required : true
    },
    email: {
        type : String,
        required : true,
        unique :true
    },
    gender: {
        type : String,
        required : true
    },
    phonenumber: {
        type : Number,
        required : true
    },
    hometown: {
        type : String
    },
    interests: {
        type : Array
    },
    experience: {
        type : Number
    },
    maritalStatus: {
        type : String,
        required : true
    },
    nationality: {
        type : String
    },
    languages: {
        type : String
    },
    currentLocation: {
        type : String
    },
    lastJobExperience: {
        type : Number,
        required : true
    },
    lastDesignation: {
        type : String,
        required : true
    },
    department: {
        type : Array
    },
    reason: {
        type : String
    }
 });

 module.exports = {
    Users : mongoose.model("Users",userSchema)
 };