const users = require("./users");
const recruiters = require("./recruiters");
const postjobs = require("./postjobs");
const appliedPostJobs = require("./appliedPostJobs");

module.exports = {
    users,
    recruiters,
    postjobs,
    appliedPostJobs
};