/**
 * @file recruiters.js
 * @summary Define and exposes methods for recruiter entity
*/


const { Recruiters } = require(__basedir + "/db/models");

 /**
  * Method for register recruiter in db
  * @param {Object} recruiterObj recruiter info to save
  */
 const createRecruiter = (recruiterObj)=>{
    const recruiter = new Recruiters(recruiterObj);
    return recruiter.save();
 };

 /**
  * Method for getting recruiter info
  * @param {Object} recruiterData recruiterData 
  */
 const getRecruiter = (recruiterData)=> Recruiters.findOne(recruiterData).lean();
 

/**
 * Method for get recruiter data by id
 * @param {object} recruiterId recruiterId
 */
const getRecruiterById = (recruiterId)=> Recruiters.findById(recruiterId);

 
 /**
 * Method for update recruiter by Id
 * @param {Object} recruiterId recruiterId
 * @param {Object} updates contains updated data object
 */
const updateRecruiterById =(recruiterId,updates)=>  Recruiters.updateOne({ _id: recruiterId }, { $set: updates });


 



module.exports = {
    createRecruiter,
    getRecruiter,
    getRecruiterById,
    updateRecruiterById
 };