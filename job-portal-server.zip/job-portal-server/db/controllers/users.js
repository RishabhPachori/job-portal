/**
 * @file users.js
 * @summary Define and exposes methods for user entity
 */

 const { Users } = require(__basedir + "/db/models");

 /**
  * Method for register user in db
  * @param {Object} userObj user info to save
  */
 const createUser = (userObj)=>{
    const user = new Users(userObj);
    return user.save();
 };

 /**
  * Method for getting user info
  * @param {Object} userData userData 
  */
 const getUser = (userData)=> Users.findOne(userData).lean();
 
/**
 * Method for get user data by id
 * @param {object} userId userId
 */
const getUserById = (userId)=> Users.findById(userId);

 /**
 * Method for update user by Id
 * @param {Object} userId userId
 * @param {Object} updates conatins updated data object
 */
const updateUserById =(userId,updates)=>  Users.updateOne({ _id: userId }, { $set: updates });

 

module.exports = {
    createUser,
    getUser,
    getUserById,
    updateUserById
 };