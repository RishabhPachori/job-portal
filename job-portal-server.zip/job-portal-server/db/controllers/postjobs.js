/**
 * @file postJobs.js
 * @summary Define and exposes methods for post-job entity
*/


const { Postjobs } = require(__basedir + "/db/models");

 /**
  * Method for add/post a job  in db
  * @param {Object} postObj job posts info save.
  */
 const createPostJob = (postObj)=>{
    const postJob = new Postjobs(postObj);
    return postJob.save();
 };

 

 /**
 * Method for get all post-job
 * @param {object} postJob postJob info
 */

const getPosts = (postJob)=> Postjobs.find(postJob).lean();
 

 



module.exports = {
    createPostJob,
    getPosts
 };