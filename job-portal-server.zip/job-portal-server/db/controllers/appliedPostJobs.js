/**
 * @file appliedPostJobs.js
 * @summary Define and exposes methods for Applied job-posts by user  entity
*/


const { Appliedpostjobs } = require(__basedir + "/db/models");

 /**
  * Method for add/create applied job-posts by user 
  * @param {Object} postObj job posts info save.
  */
 const createJob = (postObj)=>{
    const postJob = new Postjobs(postObj);
    return postJob.save();
 };

 

 /**
 * Method for get all post-job
 * @param {object} postJob postJob info
 */

const getPosts = (postJob)=> Postjobs.find(postJob).lean();
 

 



module.exports = {
    createJob,
    getPosts
 };