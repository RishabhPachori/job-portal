/**
 * Connection.js
 * @summary contains methods for connecting to mongoDB
 */

const mongoose = require("mongoose");
const { constants } = require("../config");

const { MONGO_URI } = constants;

/**
 * Method for connecting to mongodb
 */
const connectToMongoDb = ()=>{
    mongoose.connect(MONGO_URI,{
        useNewUrlParser: true,
        useUnifiedTopology:true,
        useCreateIndex: true
    });
    mongoose.connection.on("connected",()=>{
        console.log("MongoDb connected on port 27017");
    });
    mongoose.connection.on("error",(err)=>{
        console.log(`Error occured connecting in database : ${err}`);
    });
    mongoose.connection.on("disconnected",()=>{
        console.log("MongoDb disconnected");
    });
};

module.exports = {
    connectToMongoDb
};