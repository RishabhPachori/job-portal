/***
 * @file auth.js
 * @summary Entity Authentication and Authorization middleware
 * @description This File contains all the utility methods for authentication and verification of entities.
 */

 const jwt = require("jsonwebtoken");

 const { constants } = require("../config");
 const { throwUnAuthenticatedError } = require("../errors");
 
 const { SECRET } = constants;

 /**
  * Method to extract and verify jwt token from headers 
  * @param {Object} req HTTP request Object
  * @param {Object} res HTTP response Object
  * @param {Function} next HTTP Next callback method
  */
 const authenticateUserWithToken = async(req,res,next) =>{
    try{
        const auth = req.headers.authorization;
        if(!auth){
            throwUnAuthenticatedError("Access Denied");
        }
        const authParts = auth.split(" ");
        if(authParts.length !==2){
            throwUnAuthenticatedError("Format is: Bearer <token>");
        }
        const [ scheme, token ] = authParts;
        if(new RegExp("^Bearer$").test(scheme)){
            try{
                const user = await jwt.verify(token,SECRET);
                req.user = user;
                next();
            }catch(e){
                throwUnAuthenticatedError(e.message);
            }
        }else{
            throwUnAuthenticatedError("Format is: Bearer <token>");
        }
    }catch(error){
        return res.status(error.code).send({error: error.message});
    }
 };

/**
 * Method to generate token from a given payload 
 * @param {Object} payload payload injected in token
 */

 const createToken = payload =>{
     const tokenPayLoad = Object.assign({time: new Date().getTime() },payload);
     return jwt.sign(tokenPayLoad,SECRET,{expiresIn : "1hr"});
 };

 module.exports={
     createToken,
     authenticateUserWithToken,
 }