/**
 * @file index.js
 * @summary File contains User Routes 
 */
const { registerUser, loginUser,getPosts,addAppliedJobs,getProfile,updateProfile } = require("./controller");
const { authenticateUserWithToken } = require(__basedir+"/middlewares");


module.exports = router => {
    router.post("/register-user",registerUser);
    router.post("/login-user",loginUser);
    router.get("/user/posts",authenticateUserWithToken,getPosts);
    router.post("/user/applied-jobs",authenticateUserWithToken,addAppliedJobs);
    router.get("/user/:id",authenticateUserWithToken,getProfile);
    router.put("/user/:id",authenticateUserWithToken,updateProfile);
};