/**
 * @file controller.js
 * @summary user Controllers
 * @description It contains controller definition for user entity
 * Each method is responsible to passing data , extracting data , passing to correspond action
 * and send response back to client 
 */
const { addUserData,AuthenticateUsers,getPostData,appliedJobsData,getProfileData,updateProfileData } = require("./actions");

 /**
 * Controller for register users.
 * @param {object} req Http req object
 * @param {object} res Http res object
 */

const registerUser = async (req,res) => {
    try {
        const userObj = req.body;
        const data = await addUserData(userObj);
        return res.status(200).send(data);
        }catch (error) {
        res.status(error.code).end({
            error: error.message
        });
    }
}

 /**
 * Controller for login users.
 * @param {object} req Http req object
 * @param {object} res Http res object
 */

const loginUser = async (req,res) => {
    try {
        const userObj = req.body;
        const data = await AuthenticateUsers(userObj);
        return res.status(200).send(data);
        }catch (error) {
        res.status(error.code).end({
            error: error.message
        });
    }
}

 /**
 * Controller for get all job posts for users.
 * @param {object} req Http req object
 * @param {object} res Http res object
 */

const getPosts = async (req,res) => {
    try {
        const payload = req.user;
        const data = await getPostData(payload);
        return res.status(200).send(data);
        }catch (error) {
        res.status(error.code).end({
            error: error.message
        });
    }
}

 /**
 * Controller for add/create applied job posts for users.
 * @param {object} req Http req object
 * @param {object} res Http res object
 */

const addAppliedJobs = async (req,res) => {
    try {
        const payload = req.user;
        const postObj = req.body;
        const data = await appliedJobsData(payload,postObj);
        return res.status(200).send(data);
        }catch (error) {
        res.status(error.code).end({
            error: error.message
        });
    }
}

/**
 * Controller for get user profile data by Id.
 * @param {object} req Http req object
 * @param {object} res Http res object
 */

const getProfile = async (req,res) => {
    try {
        const payload = req.user;
        const recruiterId = req.params.id;
        const data = await getProfileData(payload,recruiterId);
        return res.status(200).send(data);
        }catch (error) {
        res.status(error.code).end({
            error: error.message
        });
    }
}

 /**
 * Controller for update users profile by Id.
 * @param {object} req Http req object
 * @param {object} res Http res object
 */

const updateProfile = async (req,res) => {
    try {
        const payload = req.user;
        const userId = req.params.id;
        const updatedData = req.body;
        const data = await updateProfileData(payload,userId,updatedData);
        return res.status(200).send(data);
        }catch (error) {
        res.status(error.code).end({
            error: error.message
        });
    }
}

module.exports = {
    registerUser,
    loginUser,
    getPosts,
    addAppliedJobs,
    getProfile,
    updateProfile
}