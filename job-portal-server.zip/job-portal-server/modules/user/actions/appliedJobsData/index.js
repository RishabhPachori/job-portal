const { appliedJobsData } = require("./appliedJobsData");

module.exports = {
    appliedJobsData
};