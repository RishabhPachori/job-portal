/**
 * @file appliedJobsData.js
 * @summary add applied job post by the users related information
 */
const { users } = require(__basedir + "/db/controllers");
const { appliedPostJobs } = require(__basedir + "/db/controllers");
const { throwBadRequestError } = require(__basedir + "/errors");




/**
 * method for create or add post-Job information
 * @param {object} payload payload is received when recruiter is authenticated.
 * @param {object} postObj post-job Object
 */


const appliedJobsData = async (payload,postObj) =>{
    const user = await users.getUser({ email: payload.email });
    postObj["user"]=user._id;
    if(user){
        const result = await appliedPostJobs.createJob(postObj);
        return {
            result:result,
            message: "Job applied successfully...!!"
        };
    }else{
        throwBadRequestError("Applied job not added..!!");
    }
};


module.exports = {
    appliedJobsData
};