/**
 * @file updateProfileData.js
 * @summary updates user profile data by Id
 */

const { users } = require(__basedir + "/db/controllers");
const bcrypt = require("bcrypt");
const { throwBadRequestError } = require(__basedir + "/errors");


/**
 * Method for updates user profile data by Id
 * @param {object} payload payload is received when user is authenticated.
 * @param {number} userId userId
 * @param {object} updatedData updated Data
 */

const updateProfileData = async (payload,userId,updatedData)=>{
    updatedData.password = await bcrypt.hash(updatedData.password,10);
    const user = await users.getUser({ email:payload.email });
    if(user){
        const updateData = await users.updateUserById(userId,updatedData);
        return updateData;
    }else{
        throwBadRequestError("User is not exist");
    }

};



module.exports = {
    updateProfileData
};