const { getPostData } = require("./getPostData");

module.exports={
    getPostData
};