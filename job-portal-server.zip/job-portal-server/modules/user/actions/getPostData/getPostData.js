/**
 * @file getPostData.js
 * @summary get all job-posts from all users.
 */
const { users } = require(__basedir + "/db/controllers");
const { postjobs } = require(__basedir + "/db/controllers");
const { throwBadRequestError } = require(__basedir+"/errors");

/**
 * Method for get all job-posts from all users.
 * @param {object} payload payload is received when user is authenticated.
 */

const getPostData = async (payload) =>{
    const user = await users.getUser({ email: payload.email });
    if(user){
        const postJob = await postjobs.getPosts();
        return {
            data :postJob
        };        
    }else{
        throwBadRequestError("users not found");
    }
};



module.exports = {
    getPostData
};