const { addUserData } = require("./addUserData");
const { AuthenticateUsers } = require("./AuthenticateUsers");
const { getPostData } = require("./getPostData");
const { appliedJobsData } = require("./appliedJobsData");
const { getProfileData } = require("./getProfileData");
const { updateProfileData } = require("./updateProfileData");

module.exports = {
    addUserData,
    AuthenticateUsers,
    getPostData,
    appliedJobsData,
    getProfileData,
    updateProfileData
};