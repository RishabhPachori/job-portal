const { addUserData } = require("./addUserData");

module.exports = {
    addUserData
};