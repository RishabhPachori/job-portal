/**
 * @file addUserData.js
 * @summary register user related information
 */

const { users } = require(__basedir + "/db/controllers");
const bcrypt = require("bcrypt");
const { throwBadRequestError } = require(__basedir + "/errors");


/**
 * Method for register user in db
 * @param {object} userObj userobj user related info
 */

const addUserData = async userObj =>{
    const user = await users.getUser({email: userObj.email});
    if(user){
        throwBadRequestError("user already exists");
    }
    userObj.password = await bcrypt.hash(userObj.password,10);
    const result = await users.createUser(userObj);
    return {
        user : result,
        message: "User registered successfully...!!"
    };
    
};


module.exports = {
    addUserData
};