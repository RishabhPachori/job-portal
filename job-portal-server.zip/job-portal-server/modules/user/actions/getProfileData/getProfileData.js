/**
 * @file getProfileData.js
 * @summary get user by id 
 */

const { users } = require(__basedir + "/db/controllers");
const { throwBadRequestError } = require(__basedir+"/errors");


/**
 * Method for get user profile data by Id
 * @param {Object} payload payload is received when user is authenticated.  
 */


const getProfileData = async (payload,userId) =>{
    const user = await users.getUser({ email:payload.email });
    if(user){
        const userData = await users.getUserById(userId);
        return userData;
    }else{
        throwBadRequestError("User Not Found");
    }
};


module.exports = {
    getProfileData
};
