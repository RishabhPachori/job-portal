/**
 * @file AuthenticateUsers.js
 * @summary check user password validation and create Jwt token
 */


const { users } = require(__basedir + "/db/controllers");
const bcrypt = require("bcrypt");
const { throwUnAuthenticatedError } = require(__basedir+"/errors");
const {createToken} = require(__basedir+"/middlewares");

/**
 * Method for user validation and create token
 * @param {object} userObj userobj like email and password
 */
const AuthenticateUsers = async userObj =>{
    const user = await users.getUser({ email:userObj.email });
    if(user){
        const validatepassword = await bcrypt.compare(userObj.password,user.password);
        if(!validatepassword){
            throwUnAuthenticatedError("Invalid Email or Password");
        }else{
            const token = createToken(user);
            return {
                token : token,
                message: "You are successfully login...!!!"
            };
        }
    }else{
        throwUnAuthenticatedError("Invalid Email or Password");
    }
        
};



 module.exports= {
    AuthenticateUsers
 }