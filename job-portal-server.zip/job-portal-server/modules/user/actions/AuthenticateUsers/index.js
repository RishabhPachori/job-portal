const { AuthenticateUsers } = require("./AuthenticateUsers");

module.exports = {
    AuthenticateUsers
};