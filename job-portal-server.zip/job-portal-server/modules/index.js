/**
 * @file index.js
 * @summary file intiates routes
 */
const user = require("./user");
const recruiter = require("./recruiter");


const initiatesRoutes = router => {
    // all modules with routes will be added here
    user(router);
    recruiter(router);
};

module.exports = initiatesRoutes;
