/**
 * @file index.js
 * @summary File contains Products Routes 
 */
const { registerRecruiter,loginRecruiter,postJob,getPosts,getProfile,updateProfile } = require("./controller");
const { authenticateUserWithToken } = require(__basedir+"/middlewares");

module.exports = router => {
    router.post("/register-recruiter",registerRecruiter);
    router.post("/login-recruiter",loginRecruiter);
    router.post("/post-job",authenticateUserWithToken,postJob);
    router.get("/recruiter/posts",authenticateUserWithToken,getPosts);
    router.get("/recruiter/:id",authenticateUserWithToken,getProfile);
    router.put("/recruiter/:id",authenticateUserWithToken,updateProfile);
};