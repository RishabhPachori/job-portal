/**
 * @file controller.js
 * @summary recruiter Controllers
 * @description It contains controller definition for recruiter entity
 * Each method is responsible to passing data , extracting data , passing to correspond action
 * and send response back to client 
 */
const { addRecruiterData,AuthenticateRecruiter,addPostJob,getAllPosts,getProfileData,updateProfileData } = require("./actions");

 /**
 * Controller for register recruiters.
 * @param {object} req Http req object
 * @param {object} res Http res object
 */

const registerRecruiter = async (req,res) => {
    try {
        const recruiterObj = req.body;
        const data = await addRecruiterData(recruiterObj);
        return res.status(200).send(data);
        }catch (error) {
        res.status(error.code).end({
            error: error.message
        });
    }
}

/**
 * Controller for login recruiters.
 * @param {object} req Http req object
 * @param {object} res Http res object
 */

const loginRecruiter = async (req,res) => {
    try {
        const recruiterObj = req.body;
        const data = await AuthenticateRecruiter(recruiterObj);
        return res.status(200).send(data);
        }catch (error) {
        res.status(error.code).end({
            error: error.message
        });
    }
}

/**
 * Controller for add or create post-job.
 * @param {object} req Http req object
 * @param {object} res Http res object
 */

const postJob = async (req,res) => {
    try {
        const payload = req.user;
        const postObj = req.body;
        const data = await addPostJob(payload,postObj);
        return res.status(200).send(data);
        }catch (error) {
        res.status(error.code).end({
            error: error.message
        });
    }
}

/**
 * Controller for get all post-job.
 * @param {object} req Http req object
 * @param {object} res Http res object
 */

const getPosts = async (req,res) => {
    try {
        const payload = req.user;
        const data = await getAllPosts(payload);
        return res.status(200).send(data);
        }catch (error) {
        res.status(error.code).end({
            error: error.message
        });
    }
}

/**
 * Controller for get recruiter profile data by Id.
 * @param {object} req Http req object
 * @param {object} res Http res object
 */

const getProfile = async (req,res) => {
    try {
        const payload = req.user;
        const recruiterId = req.params.id;
        const data = await getProfileData(payload,recruiterId);
        return res.status(200).send(data);
        }catch (error) {
        res.status(error.code).end({
            error: error.message
        });
    }
}

 /**
 * Controller for update recruiters profile.
 * @param {object} req Http req object
 * @param {object} res Http res object
 */

const updateProfile = async (req,res) => {
    try {
        const payload = req.user;
        const recruiterId = req.params.id;
        const updatedData = req.body;
        const data = await updateProfileData(payload,recruiterId,updatedData);
        return res.status(200).send(data);
        }catch (error) {
        res.status(error.code).end({
            error: error.message
        });
    }
}

module.exports = {
    registerRecruiter,
    loginRecruiter,
    postJob,
    getPosts,
    getProfile,
    updateProfile
}