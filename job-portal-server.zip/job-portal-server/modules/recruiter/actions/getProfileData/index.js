const { getProfileData } = require("./getProfileData");

module.exports = {
    getProfileData
};