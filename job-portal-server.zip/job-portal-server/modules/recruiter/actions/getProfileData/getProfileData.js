/**
 * @file getProfileData.js
 * @summary get recruiter by id 
 */

const { recruiters } = require(__basedir + "/db/controllers");
const { throwBadRequestError } = require(__basedir+"/errors");


/**
 * Method for get recruiter profile data by Id
 * @param {Object} payload payload is received when recruiter is authenticated.  
 */


const getProfileData = async (payload,recruiterId) =>{
    const recruiter = await recruiters.getRecruiter({ companyEmail:payload.companyEmail });
    if(recruiter){
        const recruiterData = await recruiters.getRecruiterById(recruiterId);
        return recruiterData;
    }else{
        throwBadRequestError("Recruiter Not Found");
    }
};


module.exports = {
    getProfileData
};
