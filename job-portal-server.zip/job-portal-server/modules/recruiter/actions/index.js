const { addRecruiterData } = require("./addRecruiterData");
const { AuthenticateRecruiter } = require("./AuthenticateRecruiter");
const { addPostJob } = require("./addPostJob");
const { getAllPosts } = require("./getAllPosts");
const { getProfileData } = require("./getProfileData");
const { updateProfileData } = require("./updateProfileData");


module.exports = {
    addRecruiterData,
    AuthenticateRecruiter,
    addPostJob,
    getAllPosts,
    getProfileData,
    updateProfileData
};