/**
 * @file AuthenticateRecruiter.js
 * @summary check recruiter password validation and create Jwt token
 */


const { recruiters } = require(__basedir + "/db/controllers");
const bcrypt = require("bcrypt");
const { throwUnAuthenticatedError } = require(__basedir+"/errors");
const {createToken} = require(__basedir+"/middlewares");

/**
 * Method for recruiter validation and create token
 * @param {object} recruiterObj recruiterObj like email and password
 */
const AuthenticateRecruiter = async recruiterObj =>{
    const recruiter = await recruiters.getRecruiter({ companyEmail: recruiterObj.companyEmail });
    if(recruiter){
        const validatepassword = await bcrypt.compare(recruiterObj.password,recruiter.password);
        if(!validatepassword){
            throwUnAuthenticatedError("Invalid Email or Password");
        }else{
            const token = createToken(recruiter);
            return {
                token : token,
                message: "You are successfully login...!!!"
            };
        }
    }else{
        throwUnAuthenticatedError("Invalid Email or Password");
    }
        
};



 module.exports= {
    AuthenticateRecruiter
 }