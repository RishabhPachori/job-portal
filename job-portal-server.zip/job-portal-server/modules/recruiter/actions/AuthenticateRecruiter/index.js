const { AuthenticateRecruiter } = require("./AuthenticateRecruiter");

module.exports = {
    AuthenticateRecruiter
};