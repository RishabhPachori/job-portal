/**
 * @file getAllPosts.js
 * @summary get all post-job related information
 */
const { recruiters } = require(__basedir + "/db/controllers");
const { postjobs } = require(__basedir + "/db/controllers");
const { throwBadRequestError } = require(__basedir+"/errors");

/**
 * Method for get all post-job
 * @param {object} payload payload is received when recruiter is authenticated.
 */

const getAllPosts = async (payload) =>{
    const recruiter = await recruiters.getRecruiter({ companyEmail: payload.companyEmail });
    if(recruiter){
        const postJob = await postjobs.getPosts({recruiter:recruiter._id});
        return {
            data :postJob};        
    }else{
        throwBadRequestError("recruiter not found");
    }
};



module.exports = {
    getAllPosts
};