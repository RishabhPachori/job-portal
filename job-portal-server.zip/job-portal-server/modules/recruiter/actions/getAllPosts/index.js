const { getAllPosts } = require("./getAllPosts");

module.exports = {
    getAllPosts
};