const { addRecruiterData } = require("./addRecruiterData");

module.exports = {
    addRecruiterData
};