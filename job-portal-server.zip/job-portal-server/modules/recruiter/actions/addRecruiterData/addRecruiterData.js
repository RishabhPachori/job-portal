/**
 * @file addRecruiterData.js
 * @summary register recruiter related information
 */

const { recruiters } = require(__basedir + "/db/controllers");
const bcrypt = require("bcrypt");
const { throwBadRequestError } = require(__basedir + "/errors");


/**
 * Method for register recruiter in db
 * @param {object} recruiterObj recruiterObj recruiter related info
 */

const addRecruiterData = async recruiterObj =>{
    const recruiter = await recruiters.getRecruiter({companyEmail: recruiterObj.companyEmail});
    if(recruiter){
        throwBadRequestError("Recruiter already exists");
    }
    recruiterObj.password = await bcrypt.hash(recruiterObj.password,10);
    const result = await recruiters.createRecruiter(recruiterObj);
    return {
        recruiter : result,
        message: "Recruiter registered successfully...!!"
    };
    
};


module.exports = {
    addRecruiterData
};