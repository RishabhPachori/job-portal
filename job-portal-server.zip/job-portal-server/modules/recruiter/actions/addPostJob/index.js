const { addPostJob } = require("./addPostJob");

module.exports = {
    addPostJob
};