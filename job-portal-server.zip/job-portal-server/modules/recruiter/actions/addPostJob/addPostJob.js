/**
 * @file addPostJob.js
 * @summary add post-job related information
 */
const { recruiters } = require(__basedir + "/db/controllers");
const { postjobs } = require(__basedir + "/db/controllers");
const { throwBadRequestError } = require(__basedir + "/errors");




/**
 * method for create or add post-Job information
 * @param {object} payload payload is received when recruiter is authenticated.
 * @param {object} postObj post-job Object
 */


const addPostJob = async (payload,postObj) =>{
    const recruiter = await recruiters.getRecruiter({ companyEmail: payload.companyEmail });
    postObj["recruiter"]=recruiter._id;
    postObj["recruiter_name"]=recruiter.companyName;
    if(recruiter){
        const result = await postjobs.createPostJob(postObj);
        return {
            result:result,
            message: "Post-job added successfully...!!"
        };
    }else{
        throwBadRequestError("Post-job not added..!!");
    }
};


module.exports = {
    addPostJob
};