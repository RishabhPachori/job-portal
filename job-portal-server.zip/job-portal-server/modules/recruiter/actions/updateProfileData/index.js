const { updateProfileData } = require("./updateProfileData");

module.exports = {
    updateProfileData
};