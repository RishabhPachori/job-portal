/**
 * @file updateProfileData.js
 * @summary updates recruiter profile data by Id
 */

const { recruiters } = require(__basedir + "/db/controllers");
const bcrypt = require("bcrypt");
const { throwBadRequestError } = require(__basedir + "/errors");


/**
 * Method for updates recruiter profile data by Id
 * @param {object} payload payload is received when recruiter is authenticated.
 * @param {number} recruiterId recruiterId
 * @param {object} updatedData updated Data
 */

const updateProfileData = async (payload,recruiterId,updatedData)=>{
    updatedData.password = await bcrypt.hash(updatedData.password,10);
    const recruiter = await recruiters.getRecruiter({ companyEmail:payload.companyEmail });
    if(recruiter){
        const updateData = await recruiters.updateRecruiterById(recruiterId,updatedData);
        return updateData;
    }else{
        throwBadRequestError("Recruiter is not exist");
    }

};



module.exports = {
    updateProfileData
};